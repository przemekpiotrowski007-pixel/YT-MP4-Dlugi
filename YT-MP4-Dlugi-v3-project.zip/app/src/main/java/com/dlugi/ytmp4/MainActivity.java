package com.dlugi.ytmp4;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;

import kotlin.Unit;
import kotlin.jvm.functions.Function3;

public class MainActivity extends AppCompatActivity {

    private EditText urlInput;
    private EditText licenseInput;
    private Button downloadButton;
    private Button cookiesButton;
    private Button activateButton;
    private ProgressBar progress;
    private TextView status;
    private TextView licenseStatus;
    private Spinner typeSpinner;
    private Spinner qualitySpinner;
    private CheckBox playlistCheck;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private File cookiesFile;
    private static final String LICENSE_URL = "https://tuqpolgknmpmxdftoxfh.supabase.co/functions/v1/ytmp4-license";

    private static final String[] TYPES = {"MP4 – wideo", "MP3 – tylko dźwięk"};
    private static final String[] QUALITIES = {"Auto", "144p", "240p", "360p", "480p", "720p", "1080p", "1440p", "2160p (4K)", "MAX"};

    private final ActivityResultLauncher<String> cookiesPicker =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri == null) return;
                worker.execute(() -> {
                    try {
                        File dst = new File(getFilesDir(), "cookies.txt");
                        try (InputStream in = getContentResolver().openInputStream(uri);
                             FileOutputStream out = new FileOutputStream(dst)) {
                            if (in == null) throw new Exception("Nie mogę otworzyć pliku.");
                            byte[] buf = new byte[8192];
                            int n;
                            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                        }
                        cookiesFile = dst;
                        runOnUiThread(() -> status.setText("Cookies wczytane lokalnie. Nie są wysyłane na żaden serwer."));
                    } catch (Exception e) {
                        runOnUiThread(() -> status.setText("Błąd cookies: " + e.getMessage()));
                    }
                });
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        readSharedUrl(getIntent());
        maybeUpdateYtDlp();
        loadAndCheckLicense();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        readSharedUrl(intent);
    }

    private void buildUi() {
        int pad = dp(20);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(28), pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(7, 7, 7));

        TextView logo = new TextView(this);
        logo.setText("▶");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(38);
        logo.setGravity(Gravity.CENTER);
        logo.setBackgroundResource(R.drawable.ic_launcher);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(dp(96), dp(96));
        lpLogo.bottomMargin = dp(12);
        root.addView(logo, lpLogo);

        TextView title = new TextView(this);
        title.setText("YT MP4 Długi");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("MP4 / MP3 • jakość do MAX • playlisty");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lpSub = new LinearLayout.LayoutParams(-1, -2);
        lpSub.topMargin = dp(4);
        lpSub.bottomMargin = dp(14);
        root.addView(subtitle, lpSub);

        TextView licLabel = label("Kod dostępu / licencja");
        root.addView(licLabel);

        licenseInput = new EditText(this);
        licenseInput.setHint("np. YTMP4-...");
        licenseInput.setHintTextColor(Color.GRAY);
        licenseInput.setTextColor(Color.WHITE);
        licenseInput.setSingleLine(true);
        licenseInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        licenseInput.setBackgroundColor(Color.rgb(24, 24, 24));
        root.addView(licenseInput, new LinearLayout.LayoutParams(-1, -2));

        activateButton = new Button(this);
        activateButton.setText("AKTYWUJ / SPRAWDŹ LICENCJĘ");
        LinearLayout.LayoutParams lpAct = new LinearLayout.LayoutParams(-1, dp(48));
        lpAct.topMargin = dp(6);
        root.addView(activateButton, lpAct);

        licenseStatus = new TextView(this);
        licenseStatus.setText("Licencja: niezweryfikowana");
        licenseStatus.setTextColor(Color.GRAY);
        licenseStatus.setTextSize(12);
        licenseStatus.setPadding(0, dp(5), 0, dp(8));
        root.addView(licenseStatus, new LinearLayout.LayoutParams(-1, -2));

        urlInput = new EditText(this);
        urlInput.setHint("Wklej link YouTube / playlisty");
        urlInput.setHintTextColor(Color.GRAY);
        urlInput.setTextColor(Color.WHITE);
        urlInput.setSingleLine(true);
        urlInput.setPadding(dp(14), dp(14), dp(14), dp(14));
        urlInput.setBackgroundColor(Color.rgb(24, 24, 24));
        root.addView(urlInput, new LinearLayout.LayoutParams(-1, -2));

        TextView typeLabel = label("Format");
        root.addView(typeLabel);
        typeSpinner = spinner(TYPES);
        root.addView(typeSpinner, new LinearLayout.LayoutParams(-1, dp(52)));

        TextView qualityLabel = label("Jakość wideo");
        root.addView(qualityLabel);
        qualitySpinner = spinner(QUALITIES);
        qualitySpinner.setSelection(5); // 720p
        root.addView(qualitySpinner, new LinearLayout.LayoutParams(-1, dp(52)));

        playlistCheck = new CheckBox(this);
        playlistCheck.setText("Pobierz całą playlistę");
        playlistCheck.setTextColor(Color.WHITE);
        playlistCheck.setTextSize(15);
        LinearLayout.LayoutParams lpPlaylist = new LinearLayout.LayoutParams(-1, -2);
        lpPlaylist.topMargin = dp(8);
        root.addView(playlistCheck, lpPlaylist);

        typeSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                qualitySpinner.setEnabled(position == 0);
                updateButtonText();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        qualitySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) { updateButtonText(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        playlistCheck.setOnCheckedChangeListener((buttonView, isChecked) -> updateButtonText());

        downloadButton = new Button(this);
        downloadButton.setTextColor(Color.WHITE);
        downloadButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        downloadButton.setBackgroundColor(Color.rgb(225, 24, 33));
        LinearLayout.LayoutParams lpBtn = new LinearLayout.LayoutParams(-1, dp(58));
        lpBtn.topMargin = dp(12);
        root.addView(downloadButton, lpBtn);
        updateButtonText();

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        LinearLayout.LayoutParams lpProg = new LinearLayout.LayoutParams(-1, dp(12));
        lpProg.topMargin = dp(14);
        root.addView(progress, lpProg);

        status = new TextView(this);
        status.setText("Gotowy. Pliki trafią do Pobrane/YT-MP4-Dlugi");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(13);
        status.setPadding(0, dp(12), 0, dp(4));
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        cookiesButton = new Button(this);
        cookiesButton.setText("Cookies.txt — opcjonalnie");
        LinearLayout.LayoutParams lpCookie = new LinearLayout.LayoutParams(-1, dp(48));
        lpCookie.topMargin = dp(8);
        root.addView(cookiesButton, lpCookie);

        TextView info = new TextView(this);
        info.setText("Pobieraj wyłącznie materiały, do których masz prawa lub zgodę. Cookies zostają lokalnie w aplikacji.");
        info.setTextColor(Color.GRAY);
        info.setTextSize(11);
        info.setPadding(0, dp(8), 0, 0);
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);

        downloadButton.setOnClickListener(v -> startDownload());
        cookiesButton.setOnClickListener(v -> cookiesPicker.launch("text/*"));
        activateButton.setOnClickListener(v -> activateLicense());
    }

    private TextView label(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.LTGRAY);
        tv.setTextSize(12);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        tv.setLayoutParams(lp);
        return tv;
    }

    private Spinner spinner(String[] values) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setBackgroundColor(Color.rgb(34, 34, 34));
        return spinner;
    }

    private void updateButtonText() {
        if (downloadButton == null || typeSpinner == null || qualitySpinner == null || playlistCheck == null) return;
        boolean mp3 = typeSpinner.getSelectedItemPosition() == 1;
        String suffix = playlistCheck.isChecked() ? " PLAYLISTĘ" : "";
        if (mp3) {
            downloadButton.setText("POBIERZ MP3" + suffix);
        } else {
            String q = String.valueOf(qualitySpinner.getSelectedItem());
            downloadButton.setText("POBIERZ MP4 " + q.toUpperCase(Locale.ROOT) + suffix);
        }
    }

    private void maybeUpdateYtDlp() {
        long last = getPreferences(MODE_PRIVATE).getLong("last_update", 0L);
        if (System.currentTimeMillis() - last < 24L * 60 * 60 * 1000) return;

        status.setText("Aktualizuję silnik yt-dlp…");
        worker.execute(() -> {
            try {
                YoutubeDL.getInstance().updateYoutubeDL(this, YoutubeDL.UpdateChannel._NIGHTLY);
                getPreferences(MODE_PRIVATE).edit().putLong("last_update", System.currentTimeMillis()).apply();
                runOnUiThread(() -> status.setText("Silnik gotowy. Wklej link i pobierz."));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Silnik działa z wersją wbudowaną. Aktualizacja nie powiodła się."));
            }
        });
    }

    private void startDownload() {
        if (Build.VERSION.SDK_INT <= 28 &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 77);
            status.setText("Nadaj dostęp do pamięci i kliknij pobieranie ponownie.");
            return;
        }

        String key = licenseInput == null ? "" : licenseInput.getText().toString().trim();
        if (key.isEmpty()) {
            status.setText("Najpierw wpisz i aktywuj kod dostępu.");
            if (licenseInput != null) licenseInput.requestFocus();
            return;
        }
        downloadButton.setEnabled(false);
        status.setText("Sprawdzam licencję…");
        validateLicenseAsync(key, () -> {
            getPreferences(MODE_PRIVATE).edit().putString("license_key", key).apply();
            startDownloadAfterLicense();
        }, true);
    }

    private void startDownloadAfterLicense() {
        final String url = urlInput.getText().toString().trim();
        if (!(url.startsWith("https://") || url.startsWith("http://"))) {
            status.setText("Wklej poprawny link.");
            downloadButton.setEnabled(true);
            return;
        }

        final boolean mp3 = typeSpinner.getSelectedItemPosition() == 1;
        final boolean playlist = playlistCheck.isChecked();
        final String quality = String.valueOf(qualitySpinner.getSelectedItem());

        downloadButton.setEnabled(false);
        progress.setProgress(0);
        status.setText(playlist ? "Startuję pobieranie playlisty…" : "Startuję pobieranie…");

        worker.execute(() -> {
            try {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "YT-MP4-Dlugi");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Nie mogę utworzyć folderu Pobrane/YT-MP4-Dlugi");

                YoutubeDLRequest req = new YoutubeDLRequest(url);
                req.addOption(playlist ? "--yes-playlist" : "--no-playlist");
                req.addOption("--no-mtime");
                req.addOption("--newline");

                if (mp3) {
                    req.addOption("-x");
                    req.addOption("--audio-format", "mp3");
                    req.addOption("--audio-quality", "0");
                } else {
                    req.addOption("-f", buildVideoFormat(quality));
                    req.addOption("--merge-output-format", "mp4");
                    req.addOption("--remux-video", "mp4");
                }

                String output = playlist
                        ? dir.getAbsolutePath() + "/%(playlist_title)s/%(playlist_index)02d - %(title)s [%(id)s].%(ext)s"
                        : dir.getAbsolutePath() + "/%(title)s [%(id)s].%(ext)s";
                req.addOption("-o", output);

                if (cookiesFile != null && cookiesFile.exists()) req.addOption("--cookies", cookiesFile.getAbsolutePath());

                Function3<Float, Long, String, Unit> cb = new Function3<Float, Long, String, Unit>() {
                    @Override
                    public Unit invoke(Float p, Long eta, String line) {
                        runOnUiThread(() -> {
                            int value = p == null ? 0 : Math.max(0, Math.min(100, p.intValue()));
                            progress.setProgress(value);
                            String suffix = eta != null && eta > 0 ? " • ETA " + eta + " s" : "";
                            String prefix = playlist ? "Playlista • " : "";
                            status.setText(prefix + String.format(Locale.US, "%.1f%%", p == null ? 0f : p) + suffix);
                        });
                        return Unit.INSTANCE;
                    }
                };

                YoutubeDL.getInstance().execute(req, "yt-mp4-dlugi", cb);

                runOnUiThread(() -> {
                    progress.setProgress(100);
                    status.setText("Gotowe ✅ Pliki są w Pobrane/YT-MP4-Dlugi");
                    downloadButton.setEnabled(true);
                    Toast.makeText(this, playlist ? "Playlista pobrana" : "Pobieranie zakończone", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                String msg = e.getMessage() == null ? e.toString() : e.getMessage();
                runOnUiThread(() -> {
                    downloadButton.setEnabled(true);
                    status.setText("Błąd:\n" + shorten(msg));
                });
            }
        });
    }

    private void loadAndCheckLicense() {
        String saved = getPreferences(MODE_PRIVATE).getString("license_key", "");
        if (saved == null) saved = "";
        licenseInput.setText(saved);
        if (!saved.trim().isEmpty()) {
            validateLicenseAsync(saved.trim(), null, false);
        }
    }

    private void activateLicense() {
        String key = licenseInput.getText().toString().trim();
        if (key.isEmpty()) {
            licenseStatus.setText("Wpisz kod dostępu.");
            return;
        }
        activateButton.setEnabled(false);
        licenseStatus.setText("Sprawdzam kod…");
        validateLicenseAsync(key, () -> {
            getPreferences(MODE_PRIVATE).edit().putString("license_key", key).apply();
            Toast.makeText(this, "Licencja aktywna", Toast.LENGTH_SHORT).show();
        }, false);
    }

    private void validateLicenseAsync(String key, Runnable onValid, boolean fromDownload) {
        worker.execute(() -> {
            boolean ok = false;
            String message = "Brak odpowiedzi serwera licencji";
            HttpURLConnection conn = null;
            try {
                URL u = new URL(LICENSE_URL);
                conn = (HttpURLConnection) u.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(12000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                JSONObject body = new JSONObject();
                body.put("license_key", key);
                body.put("device_hash", getDeviceHash());
                byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
                conn.getOutputStream().write(data);
                int code = conn.getResponseCode();
                InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
                StringBuilder sb = new StringBuilder();
                if (stream != null) {
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                    }
                }
                JSONObject resp = new JSONObject(sb.length() == 0 ? "{}" : sb.toString());
                ok = resp.optBoolean("ok", false);
                message = resp.optString("message", ok ? "Dostęp aktywny" : "Licencja odrzucona");
            } catch (Exception e) {
                message = "Nie mogę sprawdzić licencji. Sprawdź internet.";
            } finally {
                if (conn != null) conn.disconnect();
            }
            final boolean finalOk = ok;
            final String finalMessage = message;
            runOnUiThread(() -> {
                activateButton.setEnabled(true);
                licenseStatus.setText(finalOk ? "Licencja: AKTYWNA ✅" : "Licencja: " + finalMessage);
                licenseStatus.setTextColor(finalOk ? Color.rgb(80, 210, 120) : Color.rgb(255, 110, 110));
                if (fromDownload && !finalOk) {
                    downloadButton.setEnabled(true);
                    status.setText(finalMessage);
                }
                if (finalOk && onValid != null) onValid.run();
            });
        });
    }

    private String getDeviceHash() {
        try {
            String raw = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID)
                    + "|" + getPackageName();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) sb.append(String.format(Locale.US, "%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "android-" + Integer.toHexString((getPackageName() + Build.MODEL).hashCode());
        }
    }

    private String buildVideoFormat(String quality) {
        if ("MAX".equals(quality)) {
            return "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best[ext=mp4]/best";
        }
        if ("Auto".equals(quality)) {
            return "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=1080]+bestaudio/best[height<=1080][ext=mp4]/best[height<=1080]";
        }
        String digits = quality.replaceAll("[^0-9]", "");
        int height;
        try { height = Integer.parseInt(digits); } catch (Exception e) { height = 720; }
        return "bestvideo[height<=" + height + "][ext=mp4]+bestaudio[ext=m4a]/" +
                "bestvideo[height<=" + height + "]+bestaudio/" +
                "best[height<=" + height + "][ext=mp4]/best[height<=" + height + "]";
    }

    private String shorten(String s) {
        if (s == null) return "Nieznany błąd";
        return s.length() > 1300 ? s.substring(0, 1300) : s;
    }

    private void readSharedUrl(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null) urlInput.setText(text.trim());
        }
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }
}
