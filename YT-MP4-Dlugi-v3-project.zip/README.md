# YT MP4 Ðługi — Android

Natywna aplikacja Android. Pobieranie odbywa się lokalnie na telefonie przez yt-dlp + FFmpeg,
bez Rendera, Railway ani Cobalta.

## Co robi
- wklejenie linku YouTube
- MP4 maks. 720p
- preferuje H.264 + M4A
- scala audio i wideo przez FFmpeg
- zapis do `Pobrane/YT-MP4-Dlugi`
- automatycznie próbuje aktualizować yt-dlp do kanału nightly raz na dobę
- opcjonalny import własnego `cookies.txt`, trzymany tylko lokalnie
- przyjmuje link przez Androidowe „Udostępnij”

## Budowanie w Android Studio
Otwórz folder jako projekt i uruchom `app`.

## Budowanie przez GitHub Actions
Wrzuć cały folder do repozytorium GitHub. Workflow `.github/workflows/build-apk.yml`
zbuduje `app-debug.apk` i doda go jako artifact.

## Ważne
YouTube potrafi zmieniać mechanizmy anty-bot. Aktualizacja yt-dlp nightly i opcjonalne cookies
zwiększają kompatybilność, ale żadna aplikacja oparta na yt-dlp nie może zagwarantować,
że każdy film będzie zawsze dostępny.

Używaj tylko do materiałów, które masz prawo pobierać.
